/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package horaseminutos;

/**
 *
 * @author Jhenifer
 */
import java.util.Scanner;
public class HoraseMinutos {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        int hr, min,hrmin;
        
        Scanner inputData = new Scanner(System.in);
    System.out.println("Digite a hora:");
    hr = inputData.nextInt(); 
    
    System.out.println("Digite os minutos:");
    min = inputData.nextInt(); 
    
    hrmin=hr*60+min;;
    
  System.out.println("Impressão é:"+hrmin);

    }
    
}
